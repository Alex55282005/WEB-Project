﻿namespace WebApplication2.models
{
    public class UserMessages
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public string text { get; set; }
        public string status { get; set; }
    }

}
