﻿namespace WebApplication2.models
{
    public class Cart
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public string articles { get; set; }
    }

}
