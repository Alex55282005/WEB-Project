﻿namespace WebApplication2.models
{
    public class User
    {
        public int user_id { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public int phone { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public int cart { get; set; }
        public string messages { get; set; }
        public string token { get; set; }
    }
}