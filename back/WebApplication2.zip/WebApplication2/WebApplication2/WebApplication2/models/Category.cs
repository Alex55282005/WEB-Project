﻿namespace WebApplication2.models
{
    public class Category
    {
        public int id { get; set; }
        public string name { get; set; }
    }

}
